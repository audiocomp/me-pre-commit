from typing import Any, Dict, List, Set, Union
from me_csv.models.service_csv import ServiceCsv, ServiceCategory


def get_src_function(
        service_category: ServiceCategory, port: Union[int, str]) -> str:
    function_lookup = {
        'ASI': 'asi', 'SDI': 'sdi', 'H_264': 'encoder', 'H_265': 'encoder',
        'JXS': 'jpeg-xs-ts-encoder', 'JXS_2110': 'jpeg-xs-2110-encoder'
    }
    if port in ['D1', 'D2', 'D3', 'D4'] and\
            service_category not in ['H_264', 'H_265']:
        function = 'ip-gateway'
    elif port in ['D1', 'D2'] and service_category in ['H_264', 'H_265']:
        function = 'encoder-2022'
    else:
        function = function_lookup[service_category]

    return function


def get_dst_function(
        service_category: ServiceCategory, port: Union[int, str]) -> str:
    '''
    return function id for destination port
    '''
    function_lookup = {
        'ASI': 'asi', 'SDI': 'sdi', 'H_264': 'asi', 'H_265': 'asi',
        'JXS': 'jpeg-xs-ts-decoder', 'JXS_2110': 'jpeg-xs-2110-decoder'
    }
    if port in ['D1', 'D2', 'D3', 'D4']:
        function = 'ip-gateway'
    elif port in ['1A', '1B', '1C', '1D', '2A', '2B', '2C', '2D']:
        function = 'decoder'
    else:
        function = function_lookup[service_category]

    return function


def get_src_firmware(
        service: Dict[str, Any],
        src: str,
        host: str,
        function: Dict[str, Any]
        ) -> Dict[str, Any]:
    if str(service[f'{src}_ipaddress']) == host:
        function[service[f'{src}_slot']] =\
            get_src_function(
                service['service_category'],
                service[f'{src}_port']
            )
        function[service[f'{src}_tx_slot']] = 'IP-Gateway'
        if service[f'{src}_ir_local_slot']:
            function[service[f'{src}_ir_local_slot']] = 'IP-Gateway'
    return function


def get_dst_firmware(
        service: Dict[str, Any],
        dst: str,
        host: str,
        function: Dict[str, Any]
        ) -> Dict[str, Any]:
    if str(service[f'{dst}_ipaddress']) == host:
        function[service[f'{dst}_slot']] =\
            get_dst_function(
                service['service_category'],
                service[f'{dst}_port']
            )
        function[service[f'{dst}_rx_slot']] = 'IP-Gateway'
        if service[f'{dst}_or_rx_slot']:
            function[service[f'{dst}_or_rx_slot']] = 'IP-Gateway'
    return function


def get_firmware(
        service_list: List[ServiceCsv],
        hosts: Set[str]
        ) -> Dict[str, Set[int]]:
    firmware = {}
    for host in hosts:
        function = {}
        for service in service_list:
            service = service.dict()
            for src in ['source_1', 'source_2']:
                function = get_src_firmware(service, src, host, function)
            for dst in ['dest_1', 'dest_2']:
                function = get_dst_firmware(service, dst, host, function)
        firmware[host] = sorted(function.items())
    return firmware
