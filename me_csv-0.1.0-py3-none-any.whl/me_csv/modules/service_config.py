from me_csv.models.service_config import ServiceConfig
from me_csv.modules.log_config import log
from pydantic import parse_obj_as


def load_config():
    try:
        config = parse_obj_as(
            ServiceConfig,
            {
                "template_file": "me_service.j2",
                "mermaid_template_file": "mermaid.j2",
                "overview_template_file": "overview.j2",
            },
        )
    except ValueError as e:
        log.error(f"Config Validation Error: {e}")
        return None
    return config
