from typing import Any, Dict, List, Set
from me_csv.models.service_csv import ServiceCsv


def get_port(
        service: Dict[str, Any],
        src_dst: str,
        host: str,
        port: Dict[str, Any]
        ) -> Dict[str, Any]:
    if str(service[f'{src_dst}_ipaddress']) == host:
        if service[f'{src_dst}_slot'] not in port:
            port[service[f'{src_dst}_slot']] = {}
        if service[f'{src_dst}_port'] not in ['D1', 'D2', 'D3', 'D4']:
            port[service[f'{src_dst}_slot']][service[f'{src_dst}_port']]\
                = f"{service['service_name']} - {src_dst}"
        else:
            in_out = 'in' if src_dst in ['source_1', 'source_2'] else 'out'
            ip_port = (
                f"{service[f'{src_dst}_port']}:"
                f"{service[f'{src_dst}_ip_{in_out}put_vlan_id']}   "
                f"{service[f'{src_dst}_ip_{in_out}put_mcast_group']}:"
                f"{service[f'{src_dst}_ip_{in_out}put_mcast_port']}"
                )
            port[service[f'{src_dst}_slot']][ip_port]\
                = f"{service['service_name']} - {src_dst}"
    return port


def get_ports(
        service_list: List[ServiceCsv],
        hosts: Set[str]
        ) -> Dict[str, Set[int]]:
    ports = {}
    for host in hosts:
        port = {}
        for service in service_list:
            service = service.dict()
            for src_dst in ['source_1', 'source_2', 'dest_1', 'dest_2']:
                port = get_port(service, src_dst, host, port)
        ports[host] = port
    return ports
