from typing import List, Set
from me_csv.models.service_csv import ServiceCsv


def get_hosts(service_list: List[ServiceCsv]) -> Set[str]:
    hosts = set(())
    for service in service_list:
        service = service.dict()
        hosts.add(str(service['source_1_ipaddress']))
        hosts.add(str(service['dest_1_ipaddress']))
        if service['source_2_ipaddress']:
            hosts.add(str(service['source_2_ipaddress']))
        if service['dest_2_ipaddress']:
            hosts.add(str(service['dest_2_ipaddress']))
    return sorted(hosts)
