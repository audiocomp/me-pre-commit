import json
from asyncio import to_thread
from typing import Any, Dict, Optional, Union

from jinja2 import Environment, PackageLoader, Template
from me_csv.modules.log_config import log


def load_template(template_file: str) -> Optional[Template]:
    templateLoader = PackageLoader('me_csv', 'templates')
    templateEnv = Environment(
        loader=templateLoader,
        trim_blocks=False,
        lstrip_blocks=False,
        extensions=["jinja2.ext.do"],
    )
    try:
        template = templateEnv.get_template(template_file)
    except OSError:
        log.error(f"Template file missing: {template_file}")
        template = None

    return template


async def async_load_template(template_file: str) -> Optional[Template]:
    return await to_thread(load_template, template_file)


def render_template(
    template: Template, service: Dict[str, Any]
) -> Optional[Dict[str, Any]]:
    payload: Union[Template, str] = template.render(**service)
    if payload is not None:
        # Confirm Template Render's valid JSON
        if payload != "":
            try:
                body = json.loads(
                    str.replace(payload, "True", "true")
                    .replace(  # type:ignore
                        "False", "false"
                    )
                    .replace("'", '"'),
                    strict=False,
                )
            except json.JSONDecodeError as e:
                log.error(f"Rendered Template not valid JSON: {e}")
                print(payload)
                body = None
        else:
            log.info("Rendered a Blank Template")
            body = None
    else:
        log.error("Failed to render Template")
        body = None

    return body


async def async_render_template(
    template: Template, service: Dict[str, Any]
) -> Optional[Dict[str, Any]]:
    return await to_thread(render_template, template, service)


def render_markdown_template(
    template: Template, service: Dict[str, Any]
) -> Optional[str]:
    payload: Union[Template, str] = template.render(**service)
    if payload is None:
        log.error("Failed to render Template")
    elif payload == "":
        log.info("Rendered a Blank Template")
        return None

    return payload


async def async_render_markdown_template(
    template: Template, service: Dict[str, Any]
) -> Optional[str]:
    return await to_thread(render_markdown_template, template, service)
