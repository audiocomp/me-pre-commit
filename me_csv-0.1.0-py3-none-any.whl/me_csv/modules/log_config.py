import logging
import os
import sys
from time import gmtime

# Configure Logging
LOGLEVEL = os.environ.get("LOGLEVEL", "ERROR").upper()
if LOGLEVEL in ["DEBUG", "INFO", "WARNING", "ERROR", "CRITICAL"]:
    level = logging.getLevelName(LOGLEVEL)
else:
    level = 40

log = logging.getLogger("me_ctrl")

formatter = logging.Formatter(
    "%(levelname)s | %(asctime)s | %(name)s | %(message)s"
)
formatter.converter = gmtime
console_handler = logging.StreamHandler(sys.stdout)
console_handler.setFormatter(formatter)
log.addHandler(console_handler)
log.setLevel(level)
