from asyncio import gather
from typing import Any, Dict, List, Optional

from jinja2 import Template
from me_csv.models.service_csv import ServiceCsv
from me_csv.modules.firmware import get_firmware
from me_csv.modules.host import get_hosts
from me_csv.modules.log_config import log
from me_csv.modules.port import get_ports
from me_csv.modules.template import (
    load_template,
    async_load_template,
    render_markdown_template,
    async_render_markdown_template
    )
from me_csv.modules.vlan import get_vlans

"""
These modules are used to create a service diagram in markdown using a csv file
for the service definition. The csv file is validated against the ServiceCsv
schema. It is expected that the same csv file wil be used for the automation
of service creation and deletion.
"""


async def create_service_markdown(
    service: Optional[ServiceCsv], template: Template
) -> bool:
    result = True
    if service is not None:
        # Render Jinja2 Template
        body = await async_render_markdown_template(template, service.dict())
        if body is not None:
            try:
                with open(
                    f"../docs/{service.service_name}.md", "w"
                ) as md_file:
                    md_file.write(body)
            except OSError as e:
                log.error(f"Markdown Creation Failed: {e}")
                result = False
            log.info(f"Created Markdown File docs/{service.service_name}.md")

    return result


def get_overview_data(
        service_list: List[ServiceCsv]
        ) -> Dict[str, Any]:
    hosts = get_hosts(service_list)
    services: Dict[str, Any] = {}
    services['services'] = [service.dict() for service in service_list]
    services['firmware'] = get_firmware(service_list, hosts)
    services['ports'] = get_ports(service_list, hosts)
    services['vlans'] = get_vlans(service_list, hosts)
    return services


def create_overview_markdown(
        service_list: List[ServiceCsv], template: Template
        ) -> bool:
    result = True
    if service_list != []:
        services = get_overview_data(service_list)
        # Render Jinja2 Template
        body = render_markdown_template(template, services)
        if body is not None:
            try:
                with open(
                    "../docs/service_overview.md", "w"
                ) as md_file:
                    md_file.write(body)
            except OSError as e:
                log.error(f"Markdown Creation Failed: {e}")
                result = False
            log.info("Created Markdown File docs/service_overview.md")

    return result


async def create_all_service_markdown(
    service_list: List[ServiceCsv], template_file: str
) -> List[bool]:
    result: List[bool] = []
    if service_list != []:
        # Load Jinja2 Template
        template = await async_load_template(template_file)
        if template is not None:
            # Render & Post Template for each Service
            result = await gather(
                *[
                    create_service_markdown(service, template)
                    for service in service_list
                ]
            )
    return result


def create_service_overview_markdown(
    service_list: List[ServiceCsv], template_file: str
) -> List[bool]:
    result: List[bool] = []
    if service_list != []:
        # Load Jinja2 Template
        template = load_template(template_file)
        if template is not None:
            # Render & Post Template
            result = create_overview_markdown(service_list, template)
    return result
