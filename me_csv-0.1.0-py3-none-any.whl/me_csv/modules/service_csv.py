import csv
from asyncio import to_thread
from typing import Any, Dict, List

from me_csv.models.service_csv import ServiceCsv
from me_csv.modules.log_config import log


def load_service_csv(filename: str) -> List[ServiceCsv]:
    # Open csv file
    try:
        with open(filename, mode="r") as service_schedule:
            csv_reader = csv.DictReader(
                service_schedule, skipinitialspace=True
            )
            # Build Service List from CSV
            unvalidated_service_list: List[Dict[str, Any]] = [
                {key: value if value else None for key, value in row.items()}
                for row in csv_reader
            ]
    except FileNotFoundError:
        log.error(f"csv file missing: {filename}")
        unvalidated_service_list = []
    # Validate Service List
    if unvalidated_service_list != []:
        try:
            service_list: List[ServiceCsv] = [
                ServiceCsv(**row) for row in unvalidated_service_list
            ]
        except ValueError as e:
            log.error(f"csv validation failed: {e}")
            service_list = []
    else:
        service_list = []

    return service_list


async def async_load_service_csv(filename: str) -> List[ServiceCsv]:
    return await to_thread(load_service_csv, filename=filename)
