from typing import Any, Dict, List, Set
from me_csv.models.service_csv import ServiceCsv


def get_dst_vlan(
        service: Dict[str, Any],
        dst: str,
        host: str,
        vlan: Dict[str, Any]
        ) -> Dict[str, Any]:
    protected_port = {'D1': 'D2', 'D2': 'D1', 'D3': 'D4', 'D4': 'D3'}
    if str(service[f'{dst}_ipaddress']) == host:
        if service[f'{dst}_rx_slot'] not in vlan:
            vlan[service['dest_1_rx_slot']] = {}
        if service['service_protection']:
            ip_port = (
                f"{service[f'{dst}_rx_port']}:"
                f"{service[f'{dst}_rx_vlan_id']} & "
                f"{protected_port[service[f'{dst}_rx_port']]}:"
                f"{service[f'{dst}_rx_protected_vlan_id']}"
                )
        else:
            ip_port = (
                f"{service[f'{dst}_rx_port']}:"
                f"{service[f'{dst}_rx_vlan_id']}"
                )
        vlan[service[f'{dst}_rx_slot']][ip_port]\
            = f"{service['service_name']} - {dst}"
        if service[f'{dst}_or_rx_slot']:
            if service[f'{dst}_or_rx_slot'] not in vlan:
                vlan[service[f'{dst}_or_rx_slot']] = {}
            if service['service_protection']:
                ip_port = (
                    f"{service[f'{dst}_or_rx_port']}:"
                    f"{service[f'{dst}_or_rx_vlan_id']} & "
                    f"{protected_port[service[f'{dst}_or_rx_port']]}:"
                    f"{service[f'{dst}_or_rx_protected_vlan_id']}"
                    )
            else:
                ip_port = (
                    f"{service[f'{dst}_or_rx_port']}:"
                    f"{service[f'{dst}_or_rx_vlan_id']}"
                    )
            vlan[service[f'{dst}_or_rx_slot']][ip_port]\
                = f"{service['service_name']} - OR {dst}"
    return vlan


def get_src_vlan(
        service: Dict[str, Any],
        src: str,
        host: str,
        vlan: Dict[str, Any]
        ) -> Dict[str, Any]:
    protected_port = {'D1': 'D2', 'D2': 'D1', 'D3': 'D4', 'D4': 'D3'}
    if str(service[f'{src}_ipaddress']) == host:
        if service[f'{src}_tx_slot'] not in vlan:
            vlan[service[f'{src}_tx_slot']] = {}
        if service['service_protection']:
            ip_port = (
                f"{service[f'{src}_tx_port']}:"
                f"{service[f'{src}_tx_vlan_id']} & "
                f"{protected_port[service[f'{src}_tx_port']]}:"
                f"{service[f'{src}_tx_protected_vlan_id']}"
                )
        else:
            ip_port = (
                f"{service[f'{src}_tx_port']}:"
                f"{service[f'{src}_tx_vlan_id']}"
                )
        vlan[service[f'{src}_tx_slot']][ip_port]\
            = f"{service['service_name']} - {src}"
    return vlan


def get_vlans(
        service_list: List[ServiceCsv],
        hosts: Set[str]
        ) -> Dict[str, Set[int]]:
    vlans = {}
    for host in hosts:
        vlan = {}
        for service in service_list:
            service = service.dict()
            for src in ['source_1', 'source_2']:
                vlan = get_src_vlan(service, src, host, vlan)
            for dst in ['dest_1', 'dest_2']:
                vlan = get_dst_vlan(service, dst, host, vlan)
        vlans[host] = vlan
    return vlans
