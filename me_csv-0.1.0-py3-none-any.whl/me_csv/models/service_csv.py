from enum import Enum
from ipaddress import IPv4Address
from typing import Optional, Union

from pydantic import BaseModel, Field, validator

# port name list for validation
ports = [
    "D1",
    "D2",
    "D3",
    "D4",
    "1A",
    "1B",
    "1C",
    "1D",
    "2A",
    "2B",
    "2C",
    "2D",
    "1",
    "2",
    "3",
    "4",
    "5",
    "6",
    "7",
    "8",
    "9",
    "10",
    "11",
    "12",
    "13",
    "14",
    "15",
    "16",
    1,
    2,
    3,
    4,
    5,
    6,
    7,
    8,
    9,
    10,
    11,
    12,
    13,
    14,
    15,
    16,
]

jxs_ports = ["D1", "D2", "D3", "D4", "1", "3", "5", "7", 1, 3, 5, 7]

sdi_ports = [
    "D1",
    "D2",
    "D3",
    "D4",
    "1",
    "2",
    "3",
    "4",
    "5",
    "6",
    "7",
    "8",
    1,
    2,
    3,
    4,
    5,
    6,
    7,
    8,
]


class SourceId(str, Enum):
    source_1 = "source_1"
    source_2 = "source_2"


class FecMode(str, Enum):
    A = "A"
    B = "B"


class IpPort(str, Enum):
    D1 = "D1"
    D2 = "D2"
    D3 = "D3"
    D4 = "D4"


class Labs(str, Enum):
    dvt = "dvt"
    ewok = "ewok"
    poc = "poc"
    ap = "ap"


class ServiceCategory(str, Enum):
    ASI = "ASI"
    H_264 = "H_264"
    H_265 = "H_265"
    JXS = "JXS"
    JXS_2110 = "JXS_2110"
    SDI = "SDI"


class ServiceCsv(BaseModel):
    service_name: str = Field(title="Service Name")
    service_category: ServiceCategory = Field(title="Service Category")
    service_contract_id: int = Field(
        title="Contract ID for Service Profile", ge=0
    )
    service_profile: str = Field(title="Service Profile Name")
    service_protection: bool = Field(title="Service Protection Enabled")
    tx_bandwidth: int = Field(
        title="Service Bandwidth in Mb/s", ge=0, example=38
    )
    lab: Labs = Field(title="ME Lab ID")
    source_1_ipaddress: IPv4Address = Field(title="ME ipv4 address")
    source_1_slot: int = Field(title="ME Slot Number", ge=1, le=14, example=9)
    source_1_port: Union[str, int] = Field(
        title="ME Port Name.", ge=1, le=16, example="D1"
    )
    source_1_ip_input_vlan_id: Optional[int] = Field(
        title="Vlan Id for IP Input", ge=0, le=4094, example=101
    )
    source_1_ip_input_protected_vlan_id: Optional[int] = Field(
        title="Vlan Id for IP Input",
        ge=0,
        le=4094,
        example=101,
    )
    source_1_ip_input_protection: Optional[bool] = Field(
        title="Source Protection enabled"
    )
    source_1_ip_input_mcast_group: Optional[IPv4Address] = Field(
        title="Multicast Group Address", example="239.1.1.2"
    )
    source_1_ip_input_mcast_port: Optional[int] = Field(
        title="Multicast UDP Port", ge=1024, le=65535, example=1234
    )
    source_1_ip_input_mcast_source: Optional[IPv4Address] = Field(
        title="Multicast Source Address", example="10.1.1.2"
    )
    source_1_ip_input_protected_mcast_group: Optional[IPv4Address] = Field(
        title="Multicast Group Address", example="239.2.2.2"
    )
    source_1_ip_input_protected_mcast_port: Optional[int] = Field(
        title="Multicast UDP Port", ge=1024, le=65535, example=1234
    )
    source_1_ip_input_protected_mcast_source: Optional[IPv4Address] = Field(
        title="Multicast Source Address", example="10.2.2.2"
    )
    source_1_ip_input_ipaddress: Optional[IPv4Address] = Field(
        title="LI ipv4 Address", example="10.1.1.2"
    )
    source_1_ip_input_gateway: Optional[IPv4Address] = Field(
        title="LI ipv4 Gateway Address", example="10.1.1.1"
    )
    source_1_ip_input_ip_mask: Optional[int] = Field(
        title="LI ipv4 Prefix", ge=8, le=30, example=24
    )
    source_1_ip_input_protected_ipaddress: Optional[IPv4Address] = Field(
        title="LI ipv4 Address", example="10.2.2.2"
    )
    source_1_ip_input_protected_gateway: Optional[IPv4Address] = Field(
        title="LI ipv4 Gateway Address", example="10.2.2.1"
    )
    source_1_ip_input_protected_ip_mask: Optional[int] = Field(
        title="LI ipv4 Prefix", ge=8, le=30, example=24
    )
    source_1_tx_slot: int = Field(
        title="Network Output Slot", ge=1, le=14, example=1
    )
    source_1_tx_port: IpPort = Field(
        title="Network Output Primary Port Name", example="D1"
    )
    source_1_tx_vlan_id: int = Field(
        title="Network Output VLAN ID", ge=0, le=4094, example=101
    )
    source_1_tx_protected_vlan_id: Optional[int] = Field(
        title="Network Output VLAN ID", ge=0, le=4094, example=101
    )
    source_1_tx_moe: bool = Field(
        default=False, title="Should MoE be active on the Network Output Port"
    )
    source_1_tx_ipaddress: Optional[IPv4Address] = Field(
        title="LI ipv4 Address"
    )
    source_1_tx_gateway: Optional[IPv4Address] = Field(
        title="LI ipv4 Gateway Address"
    )
    source_1_tx_protected_ipaddress: Optional[IPv4Address] = Field(
        title="LI ipv4 Address"
    )
    source_1_tx_protected_gateway: Optional[IPv4Address] = Field(
        title="LI ipv4 Gateway Address"
    )
    source_1_tx_mcast_group: Optional[IPv4Address] = Field(
        title="Multicast Group Address"
    )
    source_1_tx_protected_mcast_group: Optional[IPv4Address] = Field(
        title="Multicast Group Address"
    )
    source_1_ir_backup_source: Optional[SourceId] = Field(
        title="Backup Source"
    )
    source_1_ir_local_slot: Optional[int] = Field(
        title="Network Input Slot", ge=1, le=14, example=1
    )
    source_1_ir_local_port: Optional[IpPort] = Field(
        title="Network Input Primary Port Name", example="D3"
    )
    source_1_ir_local_vlan_id: Optional[int] = Field(
        title="Network Input VLAN ID", ge=0, le=4094, example=1
    )
    source_1_ir_remote_slot: Optional[int] = Field(
        title="Network Output Slot", ge=1, le=14, example=1
    )
    source_1_ir_remote_port: Optional[IpPort] = Field(
        title="Network Output Primary Port Name", example="D3"
    )
    source_1_ir_remote_vlan_id: Optional[int] = Field(
        title="Network Output VLAN ID", ge=0, le=4094, example=2
    )
    source_1_ir_local_ipaddress: Optional[IPv4Address] = Field(
        title="LI ipv4 Address"
    )
    source_1_ir_local_gateway: Optional[IPv4Address] = Field(
        title="LI ipv4 Gateway Address"
    )
    source_1_ir_remote_ipaddress: Optional[IPv4Address] = Field(
        title="LI ipv4 Address"
    )
    source_1_ir_remote_gateway: Optional[IPv4Address] = Field(
        title="LI ipv4 Gateway Address"
    )
    source_2_ipaddress: Optional[IPv4Address] = Field(title="ME ipv4 address")
    source_2_slot: Optional[int] = Field(
        title="ME Slot Number", ge=1, le=14, example=9
    )
    source_2_port: Optional[Union[str, int]] = Field(
        title="ME Port Name.", ge=1, le=16, example="D1"
    )
    source_2_ip_input_vlan_id: Optional[int] = Field(
        title="Vlan Id for IP Input", ge=0, le=4094, example=101
    )
    source_2_ip_input_protected_vlan_id: Optional[int] = Field(
        title="Vlan Id for IP Input",
        ge=0,
        le=4094,
        example=101,
    )
    source_2_ip_input_protection: Optional[bool] = Field(
        title="Source Protection enabled"
    )
    source_2_ip_input_mcast_group: Optional[IPv4Address] = Field(
        title="Multicast Group Address", example="239.1.1.2"
    )
    source_2_ip_input_mcast_port: Optional[int] = Field(
        title="Multicast UDP Port", ge=1024, le=65535, example=1234
    )
    source_2_ip_input_mcast_source: Optional[IPv4Address] = Field(
        title="Multicast Source Address", example="10.1.1.2"
    )
    source_2_ip_input_protected_mcast_group: Optional[IPv4Address] = Field(
        title="Multicast Group Address", example="239.2.2.2"
    )
    source_2_ip_input_protected_mcast_port: Optional[int] = Field(
        title="Multicast UDP Port", ge=1024, le=65535, example=1234
    )
    source_2_ip_input_protected_mcast_source: Optional[IPv4Address] = Field(
        title="Multicast Source Address", example="10.2.2.2"
    )
    source_2_ip_input_ipaddress: Optional[IPv4Address] = Field(
        title="LI ipv4 Address", example="10.1.1.2"
    )
    source_2_ip_input_gateway: Optional[IPv4Address] = Field(
        title="LI ipv4 Gateway Address", example="10.1.1.1"
    )
    source_2_ip_input_ip_mask: Optional[int] = Field(
        title="LI ipv4 Prefix", ge=8, le=30, example=24
    )
    source_2_ip_input_protected_ipaddress: Optional[IPv4Address] = Field(
        title="LI ipv4 Address", example="10.2.2.2"
    )
    source_2_ip_input_protected_gateway: Optional[IPv4Address] = Field(
        title="LI ipv4 Gateway Address", example="10.2.2.1"
    )
    source_2_ip_input_protected_ip_mask: Optional[int] = Field(
        title="LI ipv4 Prefix", ge=8, le=30, example=24
    )
    source_2_tx_slot: Optional[int] = Field(
        title="Network Output Slot", ge=1, le=14, example=1
    )
    source_2_tx_port: Optional[IpPort] = Field(
        title="Network Output Primary Port Name", example="D1"
    )
    source_2_tx_vlan_id: Optional[int] = Field(
        title="Network Output VLAN ID", ge=0, le=4094, example=101
    )
    source_2_tx_protected_vlan_id: Optional[int] = Field(
        title="Network Output VLAN ID", ge=0, le=4094, example=101
    )
    source_2_tx_moe: bool = Field(
        default=False, title="Should MoE be active on the Network Output Port"
    )
    source_2_tx_ipaddress: Optional[IPv4Address] = Field(
        title="LI ipv4 Address"
    )
    source_2_tx_gateway: Optional[IPv4Address] = Field(
        title="LI ipv4 Gateway Address"
    )
    source_2_tx_protected_ipaddress: Optional[IPv4Address] = Field(
        title="LI ipv4 Address"
    )
    source_2_tx_protected_gateway: Optional[IPv4Address] = Field(
        title="LI ipv4 Gateway Address"
    )
    source_2_tx_mcast_group: Optional[IPv4Address] = Field(
        title="Multicast Group Address"
    )
    source_2_tx_protected_mcast_group: Optional[IPv4Address] = Field(
        title="Multicast Group Address"
    )
    source_2_ir_backup_source: Optional[SourceId] = Field(
        title="Backup Source"
    )
    source_2_ir_local_slot: Optional[int] = Field(
        title="Network Input Slot", ge=1, le=14, example=1
    )
    source_2_ir_local_port: Optional[IpPort] = Field(
        title="Network Input Primary Port Name", example="D3"
    )
    source_2_ir_local_vlan_id: Optional[int] = Field(
        title="Network Input VLAN ID", ge=0, le=4094, example=1
    )
    source_2_ir_remote_slot: Optional[int] = Field(
        title="Network Output Slot", ge=1, le=14, example=1
    )
    source_2_ir_remote_port: Optional[IpPort] = Field(
        title="Network Output Primary Port Name", example="D3"
    )
    source_2_ir_remote_vlan_id: Optional[int] = Field(
        title="Network Output VLAN ID", ge=0, le=4094, example=2
    )
    source_2_ir_local_ipaddress: Optional[IPv4Address] = Field(
        title="LI ipv4 Address"
    )
    source_2_ir_local_gateway: Optional[IPv4Address] = Field(
        title="LI ipv4 Gateway Address"
    )
    source_2_ir_remote_ipaddress: Optional[IPv4Address] = Field(
        title="LI ipv4 Address"
    )
    source_2_ir_remote_gateway: Optional[IPv4Address] = Field(
        title="LI ipv4 Gateway Address"
    )
    dest_1_ipaddress: IPv4Address = Field(title="ME ipv4 address")
    dest_1_slot: int = Field(title="ME Slot Number", ge=1, le=14, example=9)
    dest_1_port: Union[str, int] = Field(
        title="ME Port Name", ge=1, le=16, example="D1"
    )
    dest_1_ip_output_vlan_id: Optional[int] = Field(
        title="Vlan Id for IP Output",
        ge=0,
        le=4094,
        example=101,
    )
    dest_1_ip_output_protected_vlan_id: Optional[int] = Field(
        title="Vlan Id for IP Output", ge=0, le=4094, example=101
    )
    dest_1_ip_output_protection: Optional[bool] = Field(
        title="Destination Protection enabled"
    )
    dest_1_ip_output_mcast_group: Optional[IPv4Address] = Field(
        title="Multicast Group Address", example="239.1.1.2"
    )
    dest_1_ip_output_mcast_port: Optional[int] = Field(
        title="Multicast UDP Port", ge=1024, le=65535, example=1234
    )
    dest_1_ip_output_mcast_source: Optional[IPv4Address] = Field(
        title="Multicast Source Address", example="10.1.1.2"
    )
    dest_1_ip_output_protected_mcast_group: Optional[IPv4Address] = Field(
        title="Multicast Group Address", example="239.2.2.2"
    )
    dest_1_ip_output_protected_mcast_port: Optional[int] = Field(
        title="Multicast UDP Port", ge=1024, le=65535, example=1234
    )
    dest_1_ip_output_protected_mcast_source: Optional[IPv4Address] = Field(
        title="Multicast Source Address", example="10.2.2.2"
    )
    dest_1_ip_output_ipaddress: Optional[IPv4Address] = Field(
        title="LI ipv4 Address", example="10.1.1.2"
    )
    dest_1_ip_output_gateway: Optional[IPv4Address] = Field(
        title="LI ipv4 Gateway Address", example="10.1.1.1"
    )
    dest_1_ip_output_ip_mask: Optional[int] = Field(
        title="LI ipv4 Prefix", ge=8, le=30, example=24
    )
    dest_1_ip_output_protected_ipaddress: Optional[IPv4Address] = Field(
        title="LI ipv4 Address", example="10.2.2.2"
    )
    dest_1_ip_output_protected_gateway: Optional[IPv4Address] = Field(
        title="LI ipv4 Gateway Address", example="10.2.2.1"
    )
    dest_1_ip_output_protected_ip_mask: Optional[int] = Field(
        title="LI ipv4 Prefix", ge=8, le=30, example=24
    )
    dest_1_rx_slot: int = Field(
        title="Network Input Slot", ge=1, le=14, example=1
    )
    dest_1_rx_port: IpPort = Field(
        title="Network Input Primary Port Name", example="D1"
    )
    dest_1_rx_vlan_id: int = Field(
        title="Network Input VLAN ID", ge=0, le=4094, example=102
    )
    dest_1_rx_protected_vlan_id: Optional[int] = Field(
        title="Network Input VLAN ID", ge=0, le=4094, example=102
    )
    dest_1_rx_ipaddress: Optional[IPv4Address] = Field(title="LI ipv4 Address")
    dest_1_rx_gateway: Optional[IPv4Address] = Field(
        title="LI ipv4 Gateway Address"
    )
    dest_1_rx_protected_ipaddress: Optional[IPv4Address] = Field(
        title="LI ipv4 Address"
    )
    dest_1_rx_protected_gateway: Optional[IPv4Address] = Field(
        title="LI ipv4 Gateway Address"
    )
    dest_1_source: SourceId = Field(title="Primary Source")
    dest_1_or_backup_source: Optional[SourceId] = Field(title="Backup Source")
    dest_1_or_rx_slot: Optional[int] = Field(
        title="Network Input Slot", ge=1, le=14, example=9
    )
    dest_1_or_rx_port: Optional[IpPort] = Field(
        title="Network Input Primary Port Name"
    )
    dest_1_or_rx_vlan_id: Optional[int] = Field(
        title="Network Input VLAN ID", ge=0, le=4094, example=101
    )
    dest_1_or_rx_protected_vlan_id: Optional[int] = Field(
        title="Network Input VLAN ID", ge=0, le=4094, example=101
    )
    dest_1_or_ipaddress: Optional[IPv4Address] = Field(title="LI ipv4 Address")
    dest_1_or_gateway: Optional[IPv4Address] = Field(
        title="LI ipv4 Gateway Address"
    )
    dest_1_or_protected_ipaddress: Optional[IPv4Address] = Field(
        title="LI ipv4 Address"
    )
    dest_1_or_protected_gateway: Optional[IPv4Address] = Field(
        title="LI ipv4 Gateway Address"
    )
    dest_2_ipaddress: Optional[IPv4Address] = Field(title="ME ipv4 address")
    dest_2_slot: Optional[int] = Field(
        title="ME Slot Number", ge=1, le=14, example=9
    )
    dest_2_port: Optional[Union[str, int]] = Field(
        title="ME Port Name", ge=1, le=16, example="D1"
    )
    dest_2_ip_output_vlan_id: Optional[int] = Field(
        title="Vlan Id for IP Output",
        ge=0,
        le=4094,
        example=101,
    )
    dest_2_ip_output_protected_vlan_id: Optional[int] = Field(
        title="Vlan Id for IP Output", ge=0, le=4094, example=101
    )
    dest_2_ip_output_protection: Optional[bool] = Field(
        title="Destination Protection enabled"
    )
    dest_2_ip_output_mcast_group: Optional[IPv4Address] = Field(
        title="Multicast Group Address", example="239.1.1.2"
    )
    dest_2_ip_output_mcast_port: Optional[int] = Field(
        title="Multicast UDP Port", ge=1024, le=65535, example=1234
    )
    dest_2_ip_output_mcast_source: Optional[IPv4Address] = Field(
        title="Multicast Source Address", example="10.1.1.2"
    )
    dest_2_ip_output_protected_mcast_group: Optional[IPv4Address] = Field(
        title="Multicast Group Address", example="239.2.2.2"
    )
    dest_2_ip_output_protected_mcast_port: Optional[int] = Field(
        title="Multicast UDP Port", ge=1024, le=65535, example=1234
    )
    dest_2_ip_output_protected_mcast_source: Optional[IPv4Address] = Field(
        title="Multicast Source Address", example="10.2.2.2"
    )
    dest_2_ip_output_ipaddress: Optional[IPv4Address] = Field(
        title="LI ipv4 Address", example="10.1.1.2"
    )
    dest_2_ip_output_gateway: Optional[IPv4Address] = Field(
        title="LI ipv4 Gateway Address", example="10.1.1.1"
    )
    dest_2_ip_output_ip_mask: Optional[int] = Field(
        title="LI ipv4 Prefix", ge=8, le=30, example=24
    )
    dest_2_ip_output_protected_ipaddress: Optional[IPv4Address] = Field(
        title="LI ipv4 Address", example="10.2.2.2"
    )
    dest_2_ip_output_protected_gateway: Optional[IPv4Address] = Field(
        title="LI ipv4 Gateway Address", example="10.2.2.1"
    )
    dest_2_ip_output_protected_ip_mask: Optional[int] = Field(
        title="LI ipv4 Prefix", ge=8, le=30, example=24
    )
    dest_2_rx_slot: Optional[int] = Field(
        title="Network Input Slot", ge=1, le=14, example=1
    )
    dest_2_rx_port: Optional[IpPort] = Field(
        title="Network Input Primary Port Name", example="D1"
    )
    dest_2_rx_vlan_id: Optional[int] = Field(
        title="Network Input VLAN ID", ge=0, le=4094, example=102
    )
    dest_2_rx_protected_vlan_id: Optional[int] = Field(
        title="Network Input VLAN ID", ge=0, le=4094, example=102
    )
    dest_2_rx_ipaddress: Optional[IPv4Address] = Field(title="LI ipv4 Address")
    dest_2_rx_gateway: Optional[IPv4Address] = Field(
        title="LI ipv4 Gateway Address"
    )
    dest_2_rx_protected_ipaddress: Optional[IPv4Address] = Field(
        title="LI ipv4 Address"
    )
    dest_2_rx_protected_gateway: Optional[IPv4Address] = Field(
        title="LI ipv4 Gateway Address"
    )
    dest_2_source: Optional[SourceId] = Field(title="Primary Source")
    dest_2_or_backup_source: Optional[SourceId] = Field(title="Backup Source")
    dest_2_or_rx_slot: Optional[int] = Field(
        title="Network Input Slot", ge=1, le=14, example=9
    )
    dest_2_or_rx_port: Optional[IpPort] = Field(
        title="Network Input Primary Port Name"
    )
    dest_2_or_rx_vlan_id: Optional[int] = Field(
        title="Network Input VLAN ID", ge=0, le=4094, example=101
    )
    dest_2_or_rx_protected_vlan_id: Optional[int] = Field(
        title="Network Input VLAN ID", ge=0, le=4094, example=101
    )
    dest_2_or_ipaddress: Optional[IPv4Address] = Field(title="LI ipv4 Address")
    dest_2_or_gateway: Optional[IPv4Address] = Field(
        title="LI ipv4 Gateway Address"
    )
    dest_2_or_protected_ipaddress: Optional[IPv4Address] = Field(
        title="LI ipv4 Address"
    )
    dest_3_ipaddress: Optional[IPv4Address] = Field(title="ME ipv4 address")
    dest_3_slot: Optional[int] = Field(
        title="ME Slot Number", ge=1, le=14, example=9
    )
    dest_3_port: Optional[Union[str, int]] = Field(
        title="ME Port Name", ge=1, le=16, example="D1"
    )
    dest_3_ip_output_vlan_id: Optional[int] = Field(
        title="Vlan Id for IP Output",
        ge=0,
        le=4094,
        example=101,
    )
    dest_3_ip_output_protected_vlan_id: Optional[int] = Field(
        title="Vlan Id for IP Output", ge=0, le=4094, example=101
    )
    dest_3_ip_output_protection: Optional[bool] = Field(
        title="Destination Protection enabled"
    )
    dest_3_ip_output_mcast_group: Optional[IPv4Address] = Field(
        title="Multicast Group Address", example="239.1.1.2"
    )
    dest_3_ip_output_mcast_port: Optional[int] = Field(
        title="Multicast UDP Port", ge=1024, le=65535, example=1234
    )
    dest_3_ip_output_mcast_source: Optional[IPv4Address] = Field(
        title="Multicast Source Address", example="10.1.1.2"
    )
    dest_3_ip_output_protected_mcast_group: Optional[IPv4Address] = Field(
        title="Multicast Group Address", example="239.2.2.2"
    )
    dest_3_ip_output_protected_mcast_port: Optional[int] = Field(
        title="Multicast UDP Port", ge=1024, le=65535, example=1234
    )
    dest_3_ip_output_protected_mcast_source: Optional[IPv4Address] = Field(
        title="Multicast Source Address", example="10.2.2.2"
    )
    dest_3_ip_output_ipaddress: Optional[IPv4Address] = Field(
        title="LI ipv4 Address", example="10.1.1.2"
    )
    dest_3_ip_output_gateway: Optional[IPv4Address] = Field(
        title="LI ipv4 Gateway Address", example="10.1.1.1"
    )
    dest_3_ip_output_ip_mask: Optional[int] = Field(
        title="LI ipv4 Prefix", ge=8, le=30, example=24
    )
    dest_3_ip_output_protected_ipaddress: Optional[IPv4Address] = Field(
        title="LI ipv4 Address", example="10.2.2.2"
    )
    dest_3_ip_output_protected_gateway: Optional[IPv4Address] = Field(
        title="LI ipv4 Gateway Address", example="10.2.2.1"
    )
    dest_3_ip_output_protected_ip_mask: Optional[int] = Field(
        title="LI ipv4 Prefix", ge=8, le=30, example=24
    )
    dest_3_rx_slot: Optional[int] = Field(
        title="Network Input Slot", ge=1, le=14, example=1
    )
    dest_3_rx_port: Optional[IpPort] = Field(
        title="Network Input Primary Port Name", example="D1"
    )
    dest_3_rx_vlan_id: Optional[int] = Field(
        title="Network Input VLAN ID", ge=0, le=4094, example=102
    )
    dest_3_rx_protected_vlan_id: Optional[int] = Field(
        title="Network Input VLAN ID", ge=0, le=4094, example=102
    )
    dest_3_rx_ipaddress: Optional[IPv4Address] = Field(title="LI ipv4 Address")
    dest_3_rx_gateway: Optional[IPv4Address] = Field(
        title="LI ipv4 Gateway Address"
    )
    dest_3_rx_protected_ipaddress: Optional[IPv4Address] = Field(
        title="LI ipv4 Address"
    )
    dest_3_rx_protected_gateway: Optional[IPv4Address] = Field(
        title="LI ipv4 Gateway Address"
    )
    dest_3_source: Optional[SourceId] = Field(title="Primary Source")
    dest_3_or_backup_source: Optional[SourceId] = Field(title="Backup Source")
    dest_3_or_rx_slot: Optional[int] = Field(
        title="Network Input Slot", ge=1, le=14, example=9
    )
    dest_3_or_rx_port: Optional[IpPort] = Field(
        title="Network Input Primary Port Name"
    )
    dest_3_or_rx_vlan_id: Optional[int] = Field(
        title="Network Input VLAN ID", ge=0, le=4094, example=101
    )
    dest_3_or_rx_protected_vlan_id: Optional[int] = Field(
        title="Network Input VLAN ID", ge=0, le=4094, example=101
    )
    dest_3_or_ipaddress: Optional[IPv4Address] = Field(title="LI ipv4 Address")
    dest_3_or_gateway: Optional[IPv4Address] = Field(
        title="LI ipv4 Gateway Address"
    )
    dest_3_or_protected_ipaddress: Optional[IPv4Address] = Field(
        title="LI ipv4 Address"
    )
    dest_3_or_protected_gateway: Optional[IPv4Address] = Field(
        title="LI ipv4 Gateway Address"
    )
    dest_4_ipaddress: Optional[IPv4Address] = Field(title="ME ipv4 address")
    dest_4_slot: Optional[int] = Field(
        title="ME Slot Number", ge=1, le=14, example=9
    )
    dest_4_port: Optional[Union[str, int]] = Field(
        title="ME Port Name", ge=1, le=16, example="D1"
    )
    dest_4_ip_output_vlan_id: Optional[int] = Field(
        title="Vlan Id for IP Output",
        ge=0,
        le=4094,
        example=101,
    )
    dest_4_ip_output_protected_vlan_id: Optional[int] = Field(
        title="Vlan Id for IP Output", ge=0, le=4094, example=101
    )
    dest_4_ip_output_protection: Optional[bool] = Field(
        title="Destination Protection enabled"
    )
    dest_4_ip_output_mcast_group: Optional[IPv4Address] = Field(
        title="Multicast Group Address", example="239.1.1.2"
    )
    dest_4_ip_output_mcast_port: Optional[int] = Field(
        title="Multicast UDP Port", ge=1024, le=65535, example=1234
    )
    dest_4_ip_output_mcast_source: Optional[IPv4Address] = Field(
        title="Multicast Source Address", example="10.1.1.2"
    )
    dest_4_ip_output_protected_mcast_group: Optional[IPv4Address] = Field(
        title="Multicast Group Address", example="239.2.2.2"
    )
    dest_4_ip_output_protected_mcast_port: Optional[int] = Field(
        title="Multicast UDP Port", ge=1024, le=65535, example=1234
    )
    dest_4_ip_output_protected_mcast_source: Optional[IPv4Address] = Field(
        title="Multicast Source Address", example="10.2.2.2"
    )
    dest_4_ip_output_ipaddress: Optional[IPv4Address] = Field(
        title="LI ipv4 Address", example="10.1.1.2"
    )
    dest_4_ip_output_gateway: Optional[IPv4Address] = Field(
        title="LI ipv4 Gateway Address", example="10.1.1.1"
    )
    dest_4_ip_output_ip_mask: Optional[int] = Field(
        title="LI ipv4 Prefix", ge=8, le=30, example=24
    )
    dest_4_ip_output_protected_ipaddress: Optional[IPv4Address] = Field(
        title="LI ipv4 Address", example="10.2.2.2"
    )
    dest_4_ip_output_protected_gateway: Optional[IPv4Address] = Field(
        title="LI ipv4 Gateway Address", example="10.2.2.1"
    )
    dest_4_ip_output_protected_ip_mask: Optional[int] = Field(
        title="LI ipv4 Prefix", ge=8, le=30, example=24
    )
    dest_4_rx_slot: Optional[int] = Field(
        title="Network Input Slot", ge=1, le=14, example=1
    )
    dest_4_rx_port: Optional[IpPort] = Field(
        title="Network Input Primary Port Name", example="D1"
    )
    dest_4_rx_vlan_id: Optional[int] = Field(
        title="Network Input VLAN ID", ge=0, le=4094, example=102
    )
    dest_4_rx_protected_vlan_id: Optional[int] = Field(
        title="Network Input VLAN ID", ge=0, le=4094, example=102
    )
    dest_4_rx_ipaddress: Optional[IPv4Address] = Field(title="LI ipv4 Address")
    dest_4_rx_gateway: Optional[IPv4Address] = Field(
        title="LI ipv4 Gateway Address"
    )
    dest_4_rx_protected_ipaddress: Optional[IPv4Address] = Field(
        title="LI ipv4 Address"
    )
    dest_4_rx_protected_gateway: Optional[IPv4Address] = Field(
        title="LI ipv4 Gateway Address"
    )
    dest_4_source: Optional[SourceId] = Field(title="Primary Source")
    dest_4_or_backup_source: Optional[SourceId] = Field(title="Backup Source")
    dest_4_or_rx_slot: Optional[int] = Field(
        title="Network Input Slot", ge=1, le=14, example=9
    )
    dest_4_or_rx_port: Optional[IpPort] = Field(
        title="Network Input Primary Port Name"
    )
    dest_4_or_rx_vlan_id: Optional[int] = Field(
        title="Network Input VLAN ID", ge=0, le=4094, example=101
    )
    dest_4_or_rx_protected_vlan_id: Optional[int] = Field(
        title="Network Input VLAN ID", ge=0, le=4094, example=101
    )
    dest_4_or_ipaddress: Optional[IPv4Address] = Field(title="LI ipv4 Address")
    dest_4_or_gateway: Optional[IPv4Address] = Field(
        title="LI ipv4 Gateway Address"
    )
    dest_4_or_protected_ipaddress: Optional[IPv4Address] = Field(
        title="LI ipv4 Address"
    )

    class Config:
        use_enum_values = True

    @validator("source_1_port", always=True)
    def source_1_port_validator(cls, v, values):
        if v not in ports:
            raise ValueError(f"Invalid Port Name {v}")
        if v not in jxs_ports and values.get("service_category") == "JXS":
            raise ValueError(f"Invalid JXS Port Name {v}")
        if v not in sdi_ports and values.get("service_category") == "SDI":
            raise ValueError(f"Invalid SDI Port Name {v}")
        return v

    @validator("source_1_ip_input_vlan_id", always=True)
    def source_1_ip_input_vlan_id_validator(cls, v, values):
        if v is None and values.get("source_1_port") in [
            "D1",
            "D2",
            "D3",
            "D4",
        ]:
            raise ValueError("source_1_ip_input_vlan_id required")
        return v

    @validator("source_1_ip_input_protected_vlan_id", always=True)
    def source_1_ip_input_protected_vlan_id_validator(cls, v, values):
        if (
            v is None
            and values.get("source_1_ip_input_protection")
            and values.get("source_1_port") in ["D1", "D2", "D3", "D4"]
        ):
            raise ValueError("source_1_ip_input_protected_vlan_id required")
        return v

    @validator("source_1_ip_input_protection", always=True)
    def source_1_ip_input_protection_validator(cls, v, values):
        if v is None and values.get("source_1_port") in [
            "D1",
            "D2",
            "D3",
            "D4",
        ]:
            raise ValueError("source_1_ip_input_protection required")
        return v

    @validator("source_1_ip_input_mcast_group", always=True)
    def source_1_ip_input_mcast_group_validator(cls, v, values):
        if v is None and values.get("source_1_port") in [
            "D1",
            "D2",
            "D3",
            "D4",
        ]:
            raise ValueError("source_1_ip_input_mcast_group required")
        return v

    @validator("source_1_ip_input_mcast_port", always=True)
    def source_1_ip_input_mcast_port_validator(cls, v, values):
        if v is None and values.get("source_1_port") in [
            "D1",
            "D2",
            "D3",
            "D4",
        ]:
            raise ValueError("source_1_ip_input_mcast_port required")
        return v

    @validator("source_1_ip_input_mcast_source", always=True)
    def source_1_ip_input_mcast_source_validator(cls, v, values):
        if v is None and values.get("source_1_port") in [
            "D1",
            "D2",
            "D3",
            "D4",
        ]:
            raise ValueError("source_1_ip_input_mcast_source required")
        return v

    @validator("source_1_ip_input_protected_mcast_group", always=True)
    def source_1_ip_input_protected_mcast_group_validator(cls, v, values):
        if (
            v is None
            and values.get("source_1_ip_input_protection")
            and values.get("source_1_port") in ["D1", "D2", "D3", "D4"]
        ):
            raise ValueError(
                "source_1_ip_input_protected_mcast_group required"
            )
        return v

    @validator("source_1_ip_input_protected_mcast_port", always=True)
    def source_1_ip_input_protected_mcast_port_validator(cls, v, values):
        if (
            v is None
            and values.get("source_1_ip_input_protection")
            and values.get("source_1_port") in ["D1", "D2", "D3", "D4"]
        ):
            raise ValueError("source_1_ip_input_protected_mcast_port required")
        return v

    @validator("source_1_ip_input_protected_mcast_source", always=True)
    def source_1_ip_input_protected_mcast_source_validator(cls, v, values):
        if (
            v is None
            and values.get("source_1_ip_input_protection")
            and values.get("source_1_port") in ["D1", "D2", "D3", "D4"]
        ):
            raise ValueError(
                "source_1_ip_input_protected_mcast_source required"
            )
        return v

    @validator("source_1_ip_input_ipaddress", always=True)
    def source_1_ip_input_ipaddress_validator(cls, v, values):
        if (
            v is None
            and values.get("lab") in ["ewok", "poc"]
            and values.get("source_1_port") in ["D1", "D2", "D3", "D4"]
        ):
            raise ValueError("source_1_ip_input_ipaddress required")
        return v

    @validator("source_1_ip_input_gateway", always=True)
    def source_1_ip_input_gateway_validator(cls, v, values):
        if (
            v is None
            and values.get("lab") in ["ewok", "poc"]
            and values.get("source_1_port") in ["D1", "D2", "D3", "D4"]
        ):
            raise ValueError("source_1_ip_input_gateway required")
        return v

    @validator("source_1_ip_input_ip_mask", always=True)
    def source_1_ip_input_ip_mask_validator(cls, v, values):
        if (
            v is None
            and values.get("lab") in ["ewok", "poc"]
            and values.get("source_1_port") in ["D1", "D2", "D3", "D4"]
        ):
            raise ValueError("source_1_ip_input_ip_mask required")
        return v

    @validator("source_1_ip_input_protected_ipaddress", always=True)
    def source_1_ip_input_protected_ipaddress_validator(cls, v, values):
        if (
            v is None
            and values.get("lab") in ["ewok", "poc"]
            and values.get("source_1_ip_input_protection")
            and values.get("source_1_port") in ["D1", "D2", "D3", "D4"]
        ):
            raise ValueError("source_1_ip_input_protected_ipaddress required")
        return v

    @validator("source_1_ip_input_protected_gateway", always=True)
    def source_1_ip_input_protected_gateway_validator(cls, v, values):
        if (
            v is None
            and values.get("lab") in ["ewok", "poc"]
            and values.get("source_1_ip_input_protection")
            and values.get("source_1_port") in ["D1", "D2", "D3", "D4"]
        ):
            raise ValueError("source_1_ip_input_protected_gateway required")
        return v

    @validator("source_1_ip_input_protected_ip_mask", always=True)
    def source_1_ip_input_protected_ip_mask_validator(cls, v, values):
        if (
            v is None
            and values.get("lab") in ["ewok", "poc"]
            and values.get("source_1_ip_input_protection")
            and values.get("source_1_port") in ["D1", "D2", "D3", "D4"]
        ):
            raise ValueError("source_1_ip_input_protected_ip_mask required")
        return v

    @validator("source_1_tx_protected_vlan_id", always=True)
    def source_1_tx_vlan_id_validator(cls, v, values):
        if values.get("service_protection") and v is None:
            raise ValueError("source_1_tx_protected_vlan_id required")
        return v

    @validator("source_1_tx_ipaddress", always=True)
    def source_1_tx_ipaddress_validator(cls, v, values):
        if v is None and values.get("lab") in ["ewok", "poc"]:
            raise ValueError("source_1_tx_ipaddress required")
        return v

    @validator("source_1_tx_gateway", always=True)
    def source_1_tx_gateway_validator(cls, v, values):
        if v is None and values.get("lab") in ["ewok", "poc"]:
            raise ValueError("source_1_tx_gateway required")
        return v

    @validator("source_1_tx_protected_ipaddress", always=True)
    def source_1_tx_protected_ipaddress_validator(cls, v, values):
        if (
            v is None
            and values.get("lab") in ["ewok", "poc"]
            and values.get("service_protection")
        ):
            raise ValueError("source_1_tx_protected_ipaddress required")
        return v

    @validator("source_1_tx_protected_gateway", always=True)
    def source_1_tx_protected_gateway_validator(cls, v, values):
        if (
            v is None
            and values.get("lab") in ["ewok", "poc"]
            and values.get("service_protection")
        ):
            raise ValueError("source_1_tx_protected_gateway required")
        return v

    @validator("source_1_tx_mcast_group", always=True)
    def source_1_tx_mcast_group_validator(cls, v, values):
        if v is None and values.get("lab") in ["ewok", "poc"]:
            raise ValueError("source_1_tx_mcast_group required")
        return v

    @validator("source_1_tx_protected_mcast_group", always=True)
    def source_1_tx_protected_mcast_group_validator(cls, v, values):
        if (
            v is None
            and values.get("lab") in ["ewok", "poc"]
            and values.get("service_protection")
        ):
            raise ValueError("source_1_tx_protected_mcast_group required")
        return v

    @validator("source_1_ir_backup_source", always=True)
    def source_1_ir_backup_source_validator(cls, v, values):
        if v == "source_2" and values.get("source_2_ipaddress") is None:
            raise ValueError("source_2_ipaddress required")
        return v

    @validator("source_2_slot", always=True)
    def source_2_slot_validator(cls, v, values):
        if v is None and values.get("source_2_ipaddress") is not None:
            raise ValueError("source_2_slot required")
        return v

    @validator("source_2_port", always=True)
    def source_2_port_validator(cls, v, values):
        if v is not None and v not in ports:
            raise ValueError(f"Invalid Port Name {v}")
        if v is None and values.get("source_2_ipaddress") is not None:
            raise ValueError("source_2_port required")
        if (
            v is not None
            and values.get("service_category") == "JXS"
            and v not in jxs_ports
        ):
            raise ValueError(f"Invalid JXS Port Name {v}")
        if (
            v is not None
            and values.get("service_category") == "SDI"
            and v not in sdi_ports
        ):
            raise ValueError(f"Invalid SDI Port Name {v}")
        return v

    @validator("source_2_ip_input_vlan_id", always=True)
    def source_2_ip_input_vlan_id_validator(cls, v, values):
        if v is None and values.get("source_2_port") in [
            "D1",
            "D2",
            "D3",
            "D4",
        ]:
            raise ValueError("source_2_ip_input_vlan_id required")
        return v

    @validator("source_2_ip_input_protected_vlan_id", always=True)
    def source_2_ip_input_protected_vlan_id_validator(cls, v, values):
        if (
            v is None
            and values.get("source_2_ip_input_protection")
            and values.get("source_2_port") in ["D1", "D2", "D3", "D4"]
        ):
            raise ValueError("source_2_ip_input_protected_vlan_id required")
        return v

    @validator("source_2_ip_input_protection", always=True)
    def source_2_ip_input_protection_validator(cls, v, values):
        if v is None and values.get("source_2_port") in [
            "D1",
            "D2",
            "D3",
            "D4",
        ]:
            raise ValueError("source_2_ip_input_protection required")
        return v

    @validator("source_2_ip_input_mcast_group", always=True)
    def source_2_ip_input_mcast_group_validator(cls, v, values):
        if v is None and values.get("source_2_port") in [
            "D1",
            "D2",
            "D3",
            "D4",
        ]:
            raise ValueError("source_2_ip_input_mcast_group required")
        return v

    @validator("source_2_ip_input_mcast_port", always=True)
    def source_2_ip_input_mcast_port_validator(cls, v, values):
        if v is None and values.get("source_2_port") in [
            "D1",
            "D2",
            "D3",
            "D4",
        ]:
            raise ValueError("source_2_ip_input_mcast_port required")
        return v

    @validator("source_2_ip_input_mcast_source", always=True)
    def source_2_ip_input_mcast_source_validator(cls, v, values):
        if v is None and values.get("source_2_port") in [
            "D1",
            "D2",
            "D3",
            "D4",
        ]:
            raise ValueError("source_2_ip_input_mcast_source required")
        return v

    @validator("source_2_ip_input_protected_mcast_group", always=True)
    def source_2_ip_input_protected_mcast_group_validator(cls, v, values):
        if (
            v is None
            and values.get("source_2_ip_input_protection")
            and values.get("source_2_port") in ["D1", "D2", "D3", "D4"]
        ):
            raise ValueError(
                "source_2_ip_input_protected_mcast_group required"
            )
        return v

    @validator("source_2_ip_input_protected_mcast_port", always=True)
    def source_2_ip_input_protected_mcast_port_validator(cls, v, values):
        if (
            v is None
            and values.get("source_2_ip_input_protection")
            and values.get("source_2_port") in ["D1", "D2", "D3", "D4"]
        ):
            raise ValueError("source_2_ip_input_protected_mcast_port required")
        return v

    @validator("source_2_ip_input_protected_mcast_source", always=True)
    def source_2_ip_input_protected_mcast_source_validator(cls, v, values):
        if (
            v is None
            and values.get("source_2_ip_input_protection")
            and values.get("source_2_port") in ["D1", "D2", "D3", "D4"]
        ):
            raise ValueError(
                "source_2_ip_input_protected_mcast_source required"
            )
        return v

    @validator("source_2_ip_input_ipaddress", always=True)
    def source_2_ip_input_ipaddress_validator(cls, v, values):
        if (
            v is None
            and values.get("lab") in ["ewok", "poc"]
            and values.get("source_2_port") in ["D1", "D2", "D3", "D4"]
        ):
            raise ValueError("source_2_ip_input_ipaddress required")
        return v

    @validator("source_2_ip_input_gateway", always=True)
    def source_2_ip_input_gateway_validator(cls, v, values):
        if (
            v is None
            and values.get("lab") in ["ewok", "poc"]
            and values.get("source_2_port") in ["D1", "D2", "D3", "D4"]
        ):
            raise ValueError("source_2_ip_input_gateway required")
        return v

    @validator("source_2_ip_input_ip_mask", always=True)
    def source_2_ip_input_ip_mask_validator(cls, v, values):
        if (
            v is None
            and values.get("lab") in ["ewok", "poc"]
            and values.get("source_2_port") in ["D1", "D2", "D3", "D4"]
        ):
            raise ValueError("source_2_ip_input_ip_mask required")
        return v

    @validator("source_2_ip_input_protected_ipaddress", always=True)
    def source_2_ip_input_protected_ipaddress_validator(cls, v, values):
        if (
            v is None
            and values.get("lab") in ["ewok", "poc"]
            and values.get("source_2_ip_input_protection")
            and values.get("source_2_port") in ["D1", "D2", "D3", "D4"]
        ):
            raise ValueError("source_2_ip_input_protected_ipaddress required")
        return v

    @validator("source_2_ip_input_protected_gateway", always=True)
    def source_2_ip_input_protected_gateway_validator(cls, v, values):
        if (
            v is None
            and values.get("lab") in ["ewok", "poc"]
            and values.get("source_2_ip_input_protection")
            and values.get("source_2_port") in ["D1", "D2", "D3", "D4"]
        ):
            raise ValueError("source_2_ip_input_protected_gateway required")
        return v

    @validator("source_2_ip_input_protected_ip_mask", always=True)
    def source_2_ip_input_protected_ip_mask_validator(cls, v, values):
        if (
            v is None
            and values.get("lab") in ["ewok", "poc"]
            and values.get("source_2_ip_input_protection")
            and values.get("source_2_port") in ["D1", "D2", "D3", "D4"]
        ):
            raise ValueError("source_2_ip_input_protected_ip_mask required")
        return v

    @validator("source_2_tx_slot", always=True)
    def source_2_tx_slot_validator(cls, v, values):
        if v is None and values.get("source_2_ipaddress") is not None:
            raise ValueError("source_2_tx_slot required")
        return v

    @validator("source_2_tx_port", always=True)
    def source_2_tx_port_validator(cls, v, values):
        if v is None and values.get("source_2_ipaddress") is not None:
            raise ValueError("source_2_tx_port required")
        return v

    @validator("source_2_tx_vlan_id", always=True)
    def source_2_tx_vlan_validator(cls, v, values):
        if v is None and values.get("source_2_ipaddress") is not None:
            raise ValueError("source_2_tx_vlan_id required")
        return v

    @validator("source_2_tx_protected_vlan_id", always=True)
    def source_2_tx_vlan_id_validator(cls, v, values):
        if (
            v is None
            and values.get("source_2_ipaddress") is not None
            and values.get("service_protection")
        ):
            raise ValueError("source_2_tx_protected_vlan_id required")
        return v

    @validator("source_2_tx_gateway", always=True)
    def source_2_tx_gateway_validator(cls, v, values):
        if (
            v is None
            and values.get("source_2_ipaddress") is not None
            and values.get("lab") in ["ewok", "poc"]
        ):
            raise ValueError("source_2_tx_gateway required")
        return v

    @validator("source_2_tx_protected_ipaddress", always=True)
    def source_2_tx_protected_ipaddress_validator(cls, v, values):
        if (
            v is None
            and values.get("source_2_ipaddress") is not None
            and values.get("lab") in ["ewok", "poc"]
            and values.get("service_protection")
        ):
            raise ValueError("source_2_tx_protected_ipaddress required")
        return v

    @validator("source_2_tx_protected_gateway", always=True)
    def source_2_tx_protected_gateway_validator(cls, v, values):
        if (
            v is None
            and values.get("source_2_ipaddress") is not None
            and values.get("lab") in ["ewok", "poc"]
            and values.get("service_protection")
        ):
            raise ValueError("source_2_tx_protected_gateway required")
        return v

    @validator("source_2_tx_mcast_group", always=True)
    def source_2_tx_mcast_group_validator(cls, v, values):
        if (
            v is None
            and values.get("source_2_ipaddress") is not None
            and values.get("lab") in ["ewok", "poc"]
        ):
            raise ValueError("source_2_tx_mcast_group required")
        return v

    @validator("source_2_tx_protected_mcast_group", always=True)
    def source_2_tx_protected_mcast_group_validator(cls, v, values):
        if (
            v is None
            and values.get("source_2_ipaddress") is not None
            and values.get("lab") in ["ewok", "poc"]
            and values.get("service_protection")
        ):
            raise ValueError("source_2_tx_protected_mcast_group required")
        return v

    @validator("source_2_ir_backup_source", always=True)
    def source_2_ir_backup_source_validator(cls, v, values):
        if v == "source_2" and values.get("source_2_ipaddress") is None:
            raise ValueError("source_2_ipaddress required")
        return v

    @validator("dest_1_port", always=True)
    def dest_1_port_validator(cls, v):
        if v not in ports:
            raise ValueError(f"Invalid Port Name {v}")
        return v

    @validator("dest_1_ip_output_vlan_id", always=True)
    def dest_1_ip_output_vlan_id_validator(cls, v, values):
        if v is None and values.get("dest_1_port") in ["D1", "D2", "D3", "D4"]:
            raise ValueError("dest_1_ip_output_vlan_id required")
        return v

    @validator("dest_1_ip_output_protected_vlan_id", always=True)
    def dest_1_ip_output_protected_vlan_id_validator(cls, v, values):
        if (
            v is None
            and values.get("dest_1_ip_output_protection")
            and values.get("dest_1_port") in ["D1", "D2", "D3", "D4"]
        ):
            raise ValueError("dest_1_ip_output_protected_vlan_id required")
        return v

    @validator("dest_1_ip_output_protection", always=True)
    def dest_1_ip_output_protection_validator(cls, v, values):
        if v is None and values.get("dest_1_port") in ["D1", "D2", "D3", "D4"]:
            raise ValueError("dest_1_ip_output_protection required")
        return v

    @validator("dest_1_ip_output_mcast_group", always=True)
    def dest_1_ip_output_mcast_group_validator(cls, v, values):
        if v is None and values.get("dest_1_port") in ["D1", "D2", "D3", "D4"]:
            raise ValueError("dest_1_ip_output_mcast_group required")
        return v

    @validator("dest_1_ip_output_mcast_port", always=True)
    def dest_1_ip_output_mcast_port_validator(cls, v, values):
        if v is None and values.get("dest_1_port") in ["D1", "D2", "D3", "D4"]:
            raise ValueError("dest_1_ip_output_mcast_port required")
        return v

    @validator("dest_1_ip_output_mcast_source", always=True)
    def dest_1_ip_output_mcast_source_validator(cls, v, values):
        if v is None and values.get("dest_1_port") in ["D1", "D2", "D3", "D4"]:
            raise ValueError("dest_1_ip_output_mcast_source required")
        return v

    @validator("dest_1_ip_output_protected_mcast_group", always=True)
    def dest_1_ip_output_protected_mcast_group_validator(cls, v, values):
        if (
            v is None
            and values.get("dest_1_ip_output_protection")
            and values.get("dest_1_port") in ["D1", "D2", "D3", "D4"]
        ):
            raise ValueError("dest_1_ip_output_protected_mcast_group required")
        return v

    @validator("dest_1_ip_output_protected_mcast_port", always=True)
    def dest_1_ip_output_protected_mcast_port_validator(cls, v, values):
        if (
            v is None
            and values.get("dest_1_ip_output_protection")
            and values.get("dest_1_port") in ["D1", "D2", "D3", "D4"]
        ):
            raise ValueError("dest_1_ip_output_protected_mcast_port required")
        return v

    @validator("dest_1_ip_output_protected_mcast_source", always=True)
    def dest_1_ip_output_protected_mcast_source_validator(cls, v, values):
        if (
            v is None
            and values.get("dest_1_ip_output_protection")
            and values.get("dest_1_port") in ["D1", "D2", "D3", "D4"]
        ):
            raise ValueError(
                "dest_1_ip_output_protected_mcast_source required"
            )
        return v

    @validator("dest_1_ip_output_ipaddress", always=True)
    def dest_1_ip_output_ipaddress_validator(cls, v, values):
        if (
            v is None
            and values.get("lab") in ["ewok", "poc"]
            and values.get("dest_1_port") in ["D1", "D2", "D3", "D4"]
        ):
            raise ValueError("dest_1_ip_output_ipaddress required")
        return v

    @validator("dest_1_ip_output_gateway", always=True)
    def dest_1_ip_output_gateway_validator(cls, v, values):
        if (
            v is None
            and values.get("lab") in ["ewok", "poc"]
            and values.get("dest_1_port") in ["D1", "D2", "D3", "D4"]
        ):
            raise ValueError("dest_1_ip_output_gateway required")
        return v

    @validator("dest_1_ip_output_ip_mask", always=True)
    def dest_1_ip_output_ip_mask_validator(cls, v, values):
        if (
            v is None
            and values.get("lab") in ["ewok", "poc"]
            and values.get("dest_1_port") in ["D1", "D2", "D3", "D4"]
        ):
            raise ValueError("dest_1_ip_output_ip_mask required")
        return v

    @validator("dest_1_ip_output_protected_ipaddress", always=True)
    def dest_1_ip_output_protected_ipaddress_validator(cls, v, values):
        if (
            v is None
            and values.get("lab") in ["ewok", "poc"]
            and values.get("dest_1_ip_output_protection")
            and values.get("dest_1_port") in ["D1", "D2", "D3", "D4"]
        ):
            raise ValueError("dest_1_ip_output_protected_ipaddress required")
        return v

    @validator("dest_1_ip_output_protected_gateway", always=True)
    def dest_1_ip_output_protected_gateway_validator(cls, v, values):
        if (
            v is None
            and values.get("lab") in ["ewok", "poc"]
            and values.get("dest_1_ip_output_protection")
            and values.get("dest_1_port") in ["D1", "D2", "D3", "D4"]
        ):
            raise ValueError("dest_1_ip_output_protected_gateway required")
        return v

    @validator("dest_1_ip_output_protected_ip_mask", always=True)
    def dest_1_ip_output_protected_ip_mask_validator(cls, v, values):
        if (
            v is None
            and values.get("lab") in ["ewok", "poc"]
            and values.get("dest_1_ip_output_protection")
            and values.get("dest_1_port") in ["D1", "D2", "D3", "D4"]
        ):
            raise ValueError("dest_1_ip_output_protected_ip_mask required")
        return v

    @validator("dest_1_rx_protected_vlan_id", always=True)
    def dest_1_rx_protected_vlan_id_validator(cls, v, values):
        if v is None and values.get("service_protection"):
            raise ValueError("dest_1_rx_protected_vlan_id required")
        return v

    @validator("dest_1_rx_ipaddress", always=True)
    def dest_1_rx_ipaddress_validator(cls, v, values):
        if v is None and values.get("lab") in ["ewok", "poc"]:
            raise ValueError("dest_1_rx_ipaddress required")
        return v

    @validator("dest_1_rx_gateway", always=True)
    def dest_1_rx_gateway_validator(cls, v, values):
        if v is None and values.get("lab") in ["ewok", "poc"]:
            raise ValueError("dest_1_rx_gateway required")
        return v

    @validator("dest_1_rx_protected_ipaddress", always=True)
    def dest_1_rx_protected_ipaddress_validator(cls, v, values):
        if (
            v is None
            and values.get("lab") in ["ewok", "poc"]
            and values.get("service_protection")
        ):
            raise ValueError("dest_1_rx_protected_ipaddress required")
        return v

    @validator("dest_1_rx_protected_gateway", always=True)
    def dest_1_rx_protected_gateway_validator(cls, v, values):
        if (
            v is None
            and values.get("lab") in ["ewok", "poc"]
            and values.get("service_protection")
        ):
            raise ValueError("dest_1_rx_protected_gateway required")
        return v

    @validator("dest_1_source", always=True)
    def dest_1_source_validator(cls, v, values):
        if v == "source_2" and values.get("source_2_ipaddress") is None:
            raise ValueError("source_2_ipaddress required")
        return v

    @validator("dest_1_or_backup_source", always=True)
    def dest_1_or_backup_source_validator(cls, v, values):
        if v == "source_2" and values.get("source_2_ipaddress") is None:
            raise ValueError("source_2_ipaddress required")
        return v

    @validator("dest_2_slot", always=True)
    def dest_2_slot_validator(cls, v, values):
        if v is None and values.get("dest_2_port") is not None:
            raise ValueError("dest_2_slot required")
        return v

    @validator("dest_2_port", always=True)
    def dest_2_port_validator(cls, v, values):
        if v is not None and v not in ports:
            raise ValueError(f"Invalid Port Name {v}")
        if v is None and values.get("dest_2_slot") is not None:
            raise ValueError("dest_2_port required")
        return v

    @validator("dest_2_ip_output_vlan_id", always=True)
    def dest_2_ip_output_vlan_id_validator(cls, v, values):
        if v is None and values.get("dest_2_port") in ["D1", "D2", "D3", "D4"]:
            raise ValueError("dest_2_ip_output_vlan_id required")
        return v

    @validator("dest_2_ip_output_protected_vlan_id", always=True)
    def dest_2_ip_output_protected_vlan_id_validator(cls, v, values):
        if (
            v is None
            and values.get("dest_2_ip_output_protection")
            and values.get("dest_2_port") in ["D1", "D2", "D3", "D4"]
        ):
            raise ValueError("dest_2_ip_output_protected_vlan_id required")
        return v

    @validator("dest_2_ip_output_protection", always=True)
    def dest_2_ip_output_protection_validator(cls, v, values):
        if v is None and values.get("dest_2_port") in ["D1", "D2", "D3", "D4"]:
            raise ValueError("dest_2_ip_outputprotection required")
        return v

    @validator("dest_2_ip_output_mcast_group", always=True)
    def dest_2_ip_output_mcast_group_validator(cls, v, values):
        if v is None and values.get("dest_2_port") in ["D1", "D2", "D3", "D4"]:
            raise ValueError("dest_2_ip_output_mcast_group required")
        return v

    @validator("dest_2_ip_output_mcast_port", always=True)
    def dest_2_ip_output_mcast_port_validator(cls, v, values):
        if v is None and values.get("dest_2_port") in ["D1", "D2", "D3", "D4"]:
            raise ValueError("dest_2_ip_output_mcast_port required")
        return v

    @validator("dest_2_ip_output_mcast_source", always=True)
    def dest_2_ip_output_mcast_source_validator(cls, v, values):
        if v is None and values.get("dest_2_port") in ["D1", "D2", "D3", "D4"]:
            raise ValueError("dest_2_ip_output_mcast_source required")
        return v

    @validator("dest_2_ip_output_protected_mcast_group", always=True)
    def dest_2_ip_output_protected_mcast_group_validator(cls, v, values):
        if (
            v is None
            and values.get("dest_2_ip_output_protection")
            and values.get("dest_2_port") in ["D1", "D2", "D3", "D4"]
        ):
            raise ValueError("dest_2_ip_output_protected_mcast_group required")
        return v

    @validator("dest_2_ip_output_protected_mcast_port")
    def dest_2_ip_output_protected_mcast_port_validator(cls, v, values):
        if (
            v is None
            and values.get("dest_2_ip_output_protection")
            and values.get("dest_2_port") in ["D1", "D2", "D3", "D4"]
        ):
            raise ValueError("dest_2_ip_output_protected_mcast_port required")
        return v

    @validator("dest_2_ip_output_protected_mcast_source", always=True)
    def dest_2_ip_output_protected_mcast_source_validator(cls, v, values):
        if (
            v is None
            and values.get("dest_2_ip_output_protection")
            and values.get("dest_2_port") in ["D1", "D2", "D3", "D4"]
        ):
            raise ValueError(
                "dest_2_ip_output_protected_mcast_source required"
            )
        return v

    @validator("dest_2_ip_output_ipaddress", always=True)
    def dest_2_ip_output_ipaddress_validator(cls, v, values):
        if (
            v is None
            and values.get("lab") in ["ewok", "poc"]
            and values.get("dest_2_port") in ["D1", "D2", "D3", "D4"]
        ):
            raise ValueError("dest_2_ip_output_ipaddress required")
        return v

    @validator("dest_2_ip_output_gateway", always=True)
    def dest_2_ip_output_gateway_validator(cls, v, values):
        if (
            v is None
            and values.get("lab") in ["ewok", "poc"]
            and values.get("dest_2_port") in ["D1", "D2", "D3", "D4"]
        ):
            raise ValueError("dest_2_ip_output_gateway required")
        return v

    @validator("dest_2_ip_output_ip_mask", always=True)
    def dest_2_ip_output_ip_mask_validator(cls, v, values):
        if (
            v is None
            and values.get("lab") in ["ewok", "poc"]
            and values.get("dest_2_port") in ["D1", "D2", "D3", "D4"]
        ):
            raise ValueError("dest_2_ip_output_ip_mask required")
        return v

    @validator("dest_2_ip_output_protected_ipaddress", always=True)
    def dest_2_ip_output_protected_ipaddress_validator(cls, v, values):
        if (
            v is None
            and values.get("lab") in ["ewok", "poc"]
            and values.get("dest_2_ip_output_protection")
            and values.get("dest_2_port") in ["D1", "D2", "D3", "D4"]
        ):
            raise ValueError("dest_2_ip_output_protected_ipaddress required")
        return v

    @validator("dest_2_ip_output_protected_gateway", always=True)
    def dest_2_ip_output_protected_gateway_validator(cls, v, values):
        if (
            v is None
            and values.get("lab") in ["ewok", "poc"]
            and values.get("dest_2_ip_output_protection")
            and values.get("dest_2_port") in ["D1", "D2", "D3", "D4"]
        ):
            raise ValueError("dest_2_ip_output_protected_gateway required")
        return v

    @validator("dest_2_ip_output_protected_ip_mask", always=True)
    def dest_2_ip_output_protected_ip_mask_validator(cls, v, values):
        if (
            v is None
            and values.get("lab") in ["ewok", "poc"]
            and values.get("dest_2_ip_output_protection")
            and values.get("dest_2_port") in ["D1", "D2", "D3", "D4"]
        ):
            raise ValueError("dest_2_ip_output_protected_ip_mask required")
        return v

    @validator("dest_2_rx_slot", always=True)
    def dest_2_rx_slot_validator(cls, v, values):
        if v is None and values.get("dest_2_slot") is not None:
            raise ValueError("dest_2_slot required")
        return v

    @validator("dest_2_rx_port", always=True)
    def dest_2_rx_port_validator(cls, v, values):
        if v is None and values.get("dest_2_slot") is not None:
            raise ValueError("dest_2_rx_port required")
        return v

    @validator("dest_2_rx_vlan_id", always=True)
    def dest_2_rx_vlan_id_validator(cls, v, values):
        if v is None and values.get("dest_2_slot") is not None:
            raise ValueError("dest_2_rx_vlan_id required")
        return v

    @validator("dest_2_rx_protected_vlan_id", always=True)
    def dest_2_rx_protected_vlan_id_validator(cls, v, values):
        if (
            v is None
            and values.get("dest_2_slot") is not None
            and values.get("service_protection")
        ):
            raise ValueError("dest_2_rx_protected_vlan_id required")
        return v

    @validator("dest_2_rx_ipaddress", always=True)
    def dest_2_rx_ipaddress_validator(cls, v, values):
        if (
            v is None
            and values.get("dest_2_slot") is not None
            and values.get("lab") in ["ewok", "poc"]
        ):
            raise ValueError("dest_2_rx_ipaddress required")
        return v

    @validator("dest_2_rx_gateway", always=True)
    def dest_2_rx_gateway_validator(cls, v, values):
        if (
            v is None
            and values.get("dest_2_slot") is not None
            and values.get("lab") in ["ewok", "poc"]
        ):
            raise ValueError("dest_2_rx_gateway required")
        return v

    @validator("dest_2_rx_protected_ipaddress", always=True)
    def dest_2_rx_protected_ipaddress_validator(cls, v, values):
        if (
            v is None
            and values.get("dest_2_slot") is not None
            and values.get("lab") in ["ewok", "poc"]
            and values.get("service_protection")
        ):
            raise ValueError("dest_2_rx_protected_ipaddress required")
        return v

    @validator("dest_2_rx_protected_gateway", always=True)
    def dest_2_rx_protected_gateway_validator(cls, v, values):
        if (
            v is None
            and values.get("dest_2_slot") is not None
            and values.get("lab") in ["ewok", "poc"]
            and values.get("service_protection")
        ):
            raise ValueError("dest_2_rx_protected_gateway required")
        return v

    @validator("dest_2_source", always=True)
    def dest_2_source_validator(cls, v, values):
        if v == "source_2" and values.get("source_2_ipaddress") is None:
            raise ValueError("source_2_ipaddress required")
        return v

    @validator("dest_2_or_backup_source", always=True)
    def dest_2_or_backup_source_validator(cls, v, values):
        if v == "source_2" and values.get("source_2_ipaddress") is None:
            raise ValueError("source_2_ipaddress required")
        return v

    @validator("dest_3_slot", always=True)
    def dest_3_slot_validator(cls, v, values):
        if v is None and values.get("dest_3_port") is not None:
            raise ValueError("dest_3_slot required")
        return v

    @validator("dest_3_port", always=True)
    def dest_3_port_validator(cls, v, values):
        if v is not None and v not in ports:
            raise ValueError(f"Invalid Port Name {v}")
        if v is None and values.get("dest_3_slot") is not None:
            raise ValueError("dest_3_port required")
        return v

    @validator("dest_3_ip_output_vlan_id", always=True)
    def dest_3_ip_output_vlan_id_validator(cls, v, values):
        if v is None and values.get("dest_3_port") in ["D1", "D2", "D3", "D4"]:
            raise ValueError("dest_3_ip_output_vlan_id required")
        return v

    @validator("dest_3_ip_output_protected_vlan_id", always=True)
    def dest_3_ip_output_protected_vlan_id_validator(cls, v, values):
        if (
            v is None
            and values.get("dest_3_ip_output_protection")
            and values.get("dest_3_port") in ["D1", "D2", "D3", "D4"]
        ):
            raise ValueError("dest_3_ip_output_protected_vlan_id required")
        return v

    @validator("dest_3_ip_output_protection", always=True)
    def dest_3_ip_output_protection_validator(cls, v, values):
        if v is None and values.get("dest_3_port") in ["D1", "D2", "D3", "D4"]:
            raise ValueError("dest_3_ip_outputprotection required")
        return v

    @validator("dest_3_ip_output_mcast_group", always=True)
    def dest_3_ip_output_mcast_group_validator(cls, v, values):
        if v is None and values.get("dest_3_port") in ["D1", "D2", "D3", "D4"]:
            raise ValueError("dest_3_ip_output_mcast_group required")
        return v

    @validator("dest_3_ip_output_mcast_port", always=True)
    def dest_3_ip_output_mcast_port_validator(cls, v, values):
        if v is None and values.get("dest_3_port") in ["D1", "D2", "D3", "D4"]:
            raise ValueError("dest_3_ip_output_mcast_port required")
        return v

    @validator("dest_3_ip_output_mcast_source", always=True)
    def dest_3_ip_output_mcast_source_validator(cls, v, values):
        if v is None and values.get("dest_3_port") in ["D1", "D2", "D3", "D4"]:
            raise ValueError("dest_3_ip_output_mcast_source required")
        return v

    @validator("dest_3_ip_output_protected_mcast_group", always=True)
    def dest_3_ip_output_protected_mcast_group_validator(cls, v, values):
        if (
            v is None
            and values.get("dest_3_ip_output_protection")
            and values.get("dest_3_port") in ["D1", "D2", "D3", "D4"]
        ):
            raise ValueError("dest_3_ip_output_protected_mcast_group required")
        return v

    @validator("dest_3_ip_output_protected_mcast_port")
    def dest_3_ip_output_protected_mcast_port_validator(cls, v, values):
        if (
            v is None
            and values.get("dest_3_ip_output_protection")
            and values.get("dest_3_port") in ["D1", "D2", "D3", "D4"]
        ):
            raise ValueError("dest_3_ip_output_protected_mcast_port required")
        return v

    @validator("dest_3_ip_output_protected_mcast_source", always=True)
    def dest_3_ip_output_protected_mcast_source_validator(cls, v, values):
        if (
            v is None
            and values.get("dest_3_ip_output_protection")
            and values.get("dest_3_port") in ["D1", "D2", "D3", "D4"]
        ):
            raise ValueError(
                "dest_3_ip_output_protected_mcast_source required"
            )
        return v

    @validator("dest_3_ip_output_ipaddress", always=True)
    def dest_3_ip_output_ipaddress_validator(cls, v, values):
        if (
            v is None
            and values.get("lab") in ["ewok", "poc"]
            and values.get("dest_3_port") in ["D1", "D2", "D3", "D4"]
        ):
            raise ValueError("dest_3_ip_output_ipaddress required")
        return v

    @validator("dest_3_ip_output_gateway", always=True)
    def dest_3_ip_output_gateway_validator(cls, v, values):
        if (
            v is None
            and values.get("lab") in ["ewok", "poc"]
            and values.get("dest_3_port") in ["D1", "D2", "D3", "D4"]
        ):
            raise ValueError("dest_3_ip_output_gateway required")
        return v

    @validator("dest_3_ip_output_ip_mask", always=True)
    def dest_3_ip_output_ip_mask_validator(cls, v, values):
        if (
            v is None
            and values.get("lab") in ["ewok", "poc"]
            and values.get("dest_3_port") in ["D1", "D2", "D3", "D4"]
        ):
            raise ValueError("dest_3_ip_output_ip_mask required")
        return v

    @validator("dest_3_ip_output_protected_ipaddress", always=True)
    def dest_3_ip_output_protected_ipaddress_validator(cls, v, values):
        if (
            v is None
            and values.get("lab") in ["ewok", "poc"]
            and values.get("dest_3_ip_output_protection")
            and values.get("dest_3_port") in ["D1", "D2", "D3", "D4"]
        ):
            raise ValueError("dest_3_ip_output_protected_ipaddress required")
        return v

    @validator("dest_3_ip_output_protected_gateway", always=True)
    def dest_3_ip_output_protected_gateway_validator(cls, v, values):
        if (
            v is None
            and values.get("lab") in ["ewok", "poc"]
            and values.get("dest_3_ip_output_protection")
            and values.get("dest_3_port") in ["D1", "D2", "D3", "D4"]
        ):
            raise ValueError("dest_3_ip_output_protected_gateway required")
        return v

    @validator("dest_3_ip_output_protected_ip_mask", always=True)
    def dest_3_ip_output_protected_ip_mask_validator(cls, v, values):
        if (
            v is None
            and values.get("lab") in ["ewok", "poc"]
            and values.get("dest_3_ip_output_protection")
            and values.get("dest_3_port") in ["D1", "D2", "D3", "D4"]
        ):
            raise ValueError("dest_3_ip_output_protected_ip_mask required")
        return v

    @validator("dest_3_rx_slot", always=True)
    def dest_3_rx_slot_validator(cls, v, values):
        if v is None and values.get("dest_3_slot") is not None:
            raise ValueError("dest_3_slot required")
        return v

    @validator("dest_3_rx_port", always=True)
    def dest_3_rx_port_validator(cls, v, values):
        if v is None and values.get("dest_3_slot") is not None:
            raise ValueError("dest_3_rx_port required")
        return v

    @validator("dest_3_rx_vlan_id", always=True)
    def dest_3_rx_vlan_id_validator(cls, v, values):
        if v is None and values.get("dest_3_slot") is not None:
            raise ValueError("dest_3_rx_vlan_id required")
        return v

    @validator("dest_3_rx_protected_vlan_id", always=True)
    def dest_3_rx_protected_vlan_id_validator(cls, v, values):
        if (
            v is None
            and values.get("dest_3_slot") is not None
            and values.get("service_protection")
        ):
            raise ValueError("dest_3_rx_protected_vlan_id required")
        return v

    @validator("dest_3_rx_ipaddress", always=True)
    def dest_3_rx_ipaddress_validator(cls, v, values):
        if (
            v is None
            and values.get("dest_3_slot") is not None
            and values.get("lab") in ["ewok", "poc"]
        ):
            raise ValueError("dest_3_rx_ipaddress required")
        return v

    @validator("dest_3_rx_gateway", always=True)
    def dest_3_rx_gateway_validator(cls, v, values):
        if (
            v is None
            and values.get("dest_3_slot") is not None
            and values.get("lab") in ["ewok", "poc"]
        ):
            raise ValueError("dest_3_rx_gateway required")
        return v

    @validator("dest_3_rx_protected_ipaddress", always=True)
    def dest_3_rx_protected_ipaddress_validator(cls, v, values):
        if (
            v is None
            and values.get("dest_3_slot") is not None
            and values.get("lab") in ["ewok", "poc"]
            and values.get("service_protection")
        ):
            raise ValueError("dest_3_rx_protected_ipaddress required")
        return v

    @validator("dest_3_rx_protected_gateway", always=True)
    def dest_3_rx_protected_gateway_validator(cls, v, values):
        if (
            v is None
            and values.get("dest_3_slot") is not None
            and values.get("lab") in ["ewok", "poc"]
            and values.get("service_protection")
        ):
            raise ValueError("dest_3_rx_protected_gateway required")
        return v

    @validator("dest_3_source", always=True)
    def dest_3_source_validator(cls, v, values):
        if v == "source_2" and values.get("source_2_ipaddress") is None:
            raise ValueError("source_2_ipaddress required")
        return v

    @validator("dest_3_or_backup_source", always=True)
    def dest_3_or_backup_source_validator(cls, v, values):
        if v == "source_2" and values.get("source_2_ipaddress") is None:
            raise ValueError("source_2_ipaddress required")
        return v

    @validator("dest_4_slot", always=True)
    def dest_4_slot_validator(cls, v, values):
        if v is None and values.get("dest_4_port") is not None:
            raise ValueError("dest_4_slot required")
        return v

    @validator("dest_4_port", always=True)
    def dest_4_port_validator(cls, v, values):
        if v is not None and v not in ports:
            raise ValueError(f"Invalid Port Name {v}")
        if v is None and values.get("dest_4_slot") is not None:
            raise ValueError("dest_4_port required")
        return v

    @validator("dest_4_ip_output_vlan_id", always=True)
    def dest_4_ip_output_vlan_id_validator(cls, v, values):
        if v is None and values.get("dest_4_port") in ["D1", "D2", "D3", "D4"]:
            raise ValueError("dest_4_ip_output_vlan_id required")
        return v

    @validator("dest_4_ip_output_protected_vlan_id", always=True)
    def dest_4_ip_output_protected_vlan_id_validator(cls, v, values):
        if (
            v is None
            and values.get("dest_4_ip_output_protection")
            and values.get("dest_4_port") in ["D1", "D2", "D3", "D4"]
        ):
            raise ValueError("dest_4_ip_output_protected_vlan_id required")
        return v

    @validator("dest_4_ip_output_protection", always=True)
    def dest_4_ip_output_protection_validator(cls, v, values):
        if v is None and values.get("dest_4_port") in ["D1", "D2", "D3", "D4"]:
            raise ValueError("dest_4_ip_outputprotection required")
        return v

    @validator("dest_4_ip_output_mcast_group", always=True)
    def dest_4_ip_output_mcast_group_validator(cls, v, values):
        if v is None and values.get("dest_4_port") in ["D1", "D2", "D3", "D4"]:
            raise ValueError("dest_4_ip_output_mcast_group required")
        return v

    @validator("dest_4_ip_output_mcast_port", always=True)
    def dest_4_ip_output_mcast_port_validator(cls, v, values):
        if v is None and values.get("dest_4_port") in ["D1", "D2", "D3", "D4"]:
            raise ValueError("dest_4_ip_output_mcast_port required")
        return v

    @validator("dest_4_ip_output_mcast_source", always=True)
    def dest_4_ip_output_mcast_source_validator(cls, v, values):
        if v is None and values.get("dest_4_port") in ["D1", "D2", "D3", "D4"]:
            raise ValueError("dest_4_ip_output_mcast_source required")
        return v

    @validator("dest_4_ip_output_protected_mcast_group", always=True)
    def dest_4_ip_output_protected_mcast_group_validator(cls, v, values):
        if (
            v is None
            and values.get("dest_4_ip_output_protection")
            and values.get("dest_4_port") in ["D1", "D2", "D3", "D4"]
        ):
            raise ValueError("dest_4_ip_output_protected_mcast_group required")
        return v

    @validator("dest_4_ip_output_protected_mcast_port")
    def dest_4_ip_output_protected_mcast_port_validator(cls, v, values):
        if (
            v is None
            and values.get("dest_4_ip_output_protection")
            and values.get("dest_4_port") in ["D1", "D2", "D3", "D4"]
        ):
            raise ValueError("dest_4_ip_output_protected_mcast_port required")
        return v

    @validator("dest_4_ip_output_protected_mcast_source", always=True)
    def dest_4_ip_output_protected_mcast_source_validator(cls, v, values):
        if (
            v is None
            and values.get("dest_4_ip_output_protection")
            and values.get("dest_4_port") in ["D1", "D2", "D3", "D4"]
        ):
            raise ValueError(
                "dest_4_ip_output_protected_mcast_source required"
            )
        return v

    @validator("dest_4_ip_output_ipaddress", always=True)
    def dest_4_ip_output_ipaddress_validator(cls, v, values):
        if (
            v is None
            and values.get("lab") in ["ewok", "poc"]
            and values.get("dest_4_port") in ["D1", "D2", "D3", "D4"]
        ):
            raise ValueError("dest_4_ip_output_ipaddress required")
        return v

    @validator("dest_4_ip_output_gateway", always=True)
    def dest_4_ip_output_gateway_validator(cls, v, values):
        if (
            v is None
            and values.get("lab") in ["ewok", "poc"]
            and values.get("dest_4_port") in ["D1", "D2", "D3", "D4"]
        ):
            raise ValueError("dest_4_ip_output_gateway required")
        return v

    @validator("dest_4_ip_output_ip_mask", always=True)
    def dest_4_ip_output_ip_mask_validator(cls, v, values):
        if (
            v is None
            and values.get("lab") in ["ewok", "poc"]
            and values.get("dest_4_port") in ["D1", "D2", "D3", "D4"]
        ):
            raise ValueError("dest_4_ip_output_ip_mask required")
        return v

    @validator("dest_4_ip_output_protected_ipaddress", always=True)
    def dest_4_ip_output_protected_ipaddress_validator(cls, v, values):
        if (
            v is None
            and values.get("lab") in ["ewok", "poc"]
            and values.get("dest_4_ip_output_protection")
            and values.get("dest_4_port") in ["D1", "D2", "D3", "D4"]
        ):
            raise ValueError("dest_4_ip_output_protected_ipaddress required")
        return v

    @validator("dest_4_ip_output_protected_gateway", always=True)
    def dest_4_ip_output_protected_gateway_validator(cls, v, values):
        if (
            v is None
            and values.get("lab") in ["ewok", "poc"]
            and values.get("dest_4_ip_output_protection")
            and values.get("dest_4_port") in ["D1", "D2", "D3", "D4"]
        ):
            raise ValueError("dest_4_ip_output_protected_gateway required")
        return v

    @validator("dest_4_ip_output_protected_ip_mask", always=True)
    def dest_4_ip_output_protected_ip_mask_validator(cls, v, values):
        if (
            v is None
            and values.get("lab") in ["ewok", "poc"]
            and values.get("dest_4_ip_output_protection")
            and values.get("dest_4_port") in ["D1", "D2", "D3", "D4"]
        ):
            raise ValueError("dest_4_ip_output_protected_ip_mask required")
        return v

    @validator("dest_4_rx_slot", always=True)
    def dest_4_rx_slot_validator(cls, v, values):
        if v is None and values.get("dest_4_slot") is not None:
            raise ValueError("dest_4_slot required")
        return v

    @validator("dest_4_rx_port", always=True)
    def dest_4_rx_port_validator(cls, v, values):
        if v is None and values.get("dest_4_slot") is not None:
            raise ValueError("dest_4_rx_port required")
        return v

    @validator("dest_4_rx_vlan_id", always=True)
    def dest_4_rx_vlan_id_validator(cls, v, values):
        if v is None and values.get("dest_4_slot") is not None:
            raise ValueError("dest_4_rx_vlan_id required")
        return v

    @validator("dest_4_rx_protected_vlan_id", always=True)
    def dest_4_rx_protected_vlan_id_validator(cls, v, values):
        if (
            v is None
            and values.get("dest_4_slot") is not None
            and values.get("service_protection")
        ):
            raise ValueError("dest_4_rx_protected_vlan_id required")
        return v

    @validator("dest_4_rx_ipaddress", always=True)
    def dest_4_rx_ipaddress_validator(cls, v, values):
        if (
            v is None
            and values.get("dest_4_slot") is not None
            and values.get("lab") in ["ewok", "poc"]
        ):
            raise ValueError("dest_4_rx_ipaddress required")
        return v

    @validator("dest_4_rx_gateway", always=True)
    def dest_4_rx_gateway_validator(cls, v, values):
        if (
            v is None
            and values.get("dest_4_slot") is not None
            and values.get("lab") in ["ewok", "poc"]
        ):
            raise ValueError("dest_4_rx_gateway required")
        return v

    @validator("dest_4_rx_protected_ipaddress", always=True)
    def dest_4_rx_protected_ipaddress_validator(cls, v, values):
        if (
            v is None
            and values.get("dest_4_slot") is not None
            and values.get("lab") in ["ewok", "poc"]
            and values.get("service_protection")
        ):
            raise ValueError("dest_4_rx_protected_ipaddress required")
        return v

    @validator("dest_4_rx_protected_gateway", always=True)
    def dest_4_rx_protected_gateway_validator(cls, v, values):
        if (
            v is None
            and values.get("dest_4_slot") is not None
            and values.get("lab") in ["ewok", "poc"]
            and values.get("service_protection")
        ):
            raise ValueError("dest_4_rx_protected_gateway required")
        return v

    @validator("dest_4_source", always=True)
    def dest_4_source_validator(cls, v, values):
        if v == "source_2" and values.get("source_2_ipaddress") is None:
            raise ValueError("source_2_ipaddress required")
        return v

    @validator("dest_4_or_backup_source", always=True)
    def dest_4_or_backup_source_validator(cls, v, values):
        if v == "source_2" and values.get("source_2_ipaddress") is None:
            raise ValueError("source_2_ipaddress required")
        return v
