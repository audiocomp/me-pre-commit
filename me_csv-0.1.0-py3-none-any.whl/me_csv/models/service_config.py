from pydantic import BaseModel


class ServiceConfig(BaseModel):
    template_file: str
    mermaid_template_file: str
    overview_template_file: str
