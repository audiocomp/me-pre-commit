import os
import shutil

from me_csv.modules.log_config import log
from me_csv.modules.service_config import load_config
from me_csv.modules.service_csv import load_service_csv
from me_csv.modules.service_csv_markdown import (
    create_service_overview_markdown,
    create_all_service_markdown,
    )


def validate_csv(filename: str = "../appear_services.csv") -> bool:

    """
    Used to validate the me service csv file for use with me-ctrl.
    The csv file is validated against the ServiceCsv schema.
    """
    config = load_config()
    result = True
    if config is not None:
        log.info(f"Load Service CSV - {filename}")
        service_list = load_service_csv(filename)
        if service_list != []:
            log.info(f"Service CSV {filename} Validation Successful")
        else:
            log.info(f"Service CSV {filename} Validation Failed")
            result = False
    else:
        return result


async def create_csv_markdown(
        filename: str = "../appear_services.csv") -> bool:
    config = load_config()
    result = True
    if config is not None:
        log.info(f"Load Service CSV - {filename}")
        service_list = load_service_csv(filename)
        if service_list != []:
            # recreate docs folder
            if os.path.exists("../docs"):
                shutil.rmtree("../docs")
            os.makedirs("../docs")
            result = create_service_overview_markdown(
                service_list=service_list,
                template_file=config.overview_template_file,
            )
            if result is False:
                return result
            result = await create_all_service_markdown(
                service_list=service_list,
                template_file=config.mermaid_template_file,
            )
            if all(result) is False:
                result = False
        else:
            result = False
    else:
        result = False
    return result
